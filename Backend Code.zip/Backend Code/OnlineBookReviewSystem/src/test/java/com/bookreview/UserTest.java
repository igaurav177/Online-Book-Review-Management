package com.bookreview;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.bookreview.pojo.UserDetails;
import com.bookreview.repo.UserRepository;

@SpringBootTest
@TestMethodOrder(org.junit.jupiter.api.MethodOrderer.OrderAnnotation.class)

public class UserTest {
	
	@Autowired
	UserRepository urepo;

	@Test
	@Order(1)	
	public void saveUserTest(){

		UserDetails user=new UserDetails();
        user.setFirstname("Ravinder");
        user.setLastname("Sharma");
        user.setEmail("ravinder@gmail.com");
        user.setAddress("New Delhi");
        user.setPassword("ravi123");
        user.setId(3);
        user.setPhone(987828392);

        urepo.save(user);

        assertNotNull(urepo.findAll());
    }
	
	@Test
	@Order(2)
	 public void getUserTest(){

        UserDetails s = urepo.findById(2).get();

        assertThat(s.getId()).isEqualTo(2);

    }

	@Test
	@Order(3)
	public void UserUpdate() throws Exception {
	  
		UserDetails updateuser = urepo.findById(3).get();
		updateuser.setFirstname("ravi");     
		urepo.save(updateuser);     
		assertThat(updateuser.getFirstname().equals("ravi"));
	}
	
}
